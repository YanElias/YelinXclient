package com.yelinx.client;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class HudOverlay {
    private final Minecraft mc = Minecraft.func_71410_x();

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Text event) {
        if (mc.field_71439_g == null || mc.field_71474_y.field_74330_P) {
            return;
        }

        String text = "YelinX  |  " + Minecraft.func_175610_ah() + " FPS";
        mc.field_71466_p.func_175063_a(text, 6, 6, 0xFFFFD600);
    }
}
