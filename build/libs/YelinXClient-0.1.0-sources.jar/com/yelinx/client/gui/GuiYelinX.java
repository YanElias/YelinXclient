package com.yelinx.client.gui;

import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class GuiYelinX extends GuiScreen {
    private static final int YELLOW = 0xFFFFD600;
    private static final int GRAPHITE = 0xFF202020;
    private static final int PANEL = 0xFF292929;
    private static final int WHITE = 0xFFF5F5F5;

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        func_146276_q_();

        int left = field_146294_l / 2 - 150;
        int top = field_146295_m / 2 - 105;
        int right = field_146294_l / 2 + 150;
        int bottom = field_146295_m / 2 + 105;

        func_73734_a(left, top, right, bottom, GRAPHITE);
        func_73734_a(left, top, right, top + 3, YELLOW);

        func_73732_a(field_146289_q, "YelinX Client", field_146294_l / 2, top + 16, YELLOW);
        func_73732_a(field_146289_q, "YOUR GAME. YOUR STYLE.", field_146294_l / 2, top + 34, WHITE);

        func_73734_a(left + 18, top + 58, right - 18, top + 86, PANEL);
        func_73732_a(field_146289_q, "Client menu foundation", field_146294_l / 2, top + 68, WHITE);

        func_73734_a(left + 18, top + 94, right - 18, top + 122, PANEL);
        func_73732_a(field_146289_q, "More modules coming soon", field_146294_l / 2, top + 104, WHITE);

        func_73732_a(field_146289_q, "Press ESC to return", field_146294_l / 2, bottom - 20, 0xFFBDBDBD);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) {
            field_146297_k.func_147108_a(null);
        } else {
            super.func_73869_a(typedChar, keyCode);
        }
    }

    @Override
    public boolean func_73868_f() {
        return false;
    }
}
