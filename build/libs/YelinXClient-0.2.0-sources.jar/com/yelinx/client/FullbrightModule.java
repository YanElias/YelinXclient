package com.yelinx.client;

import net.minecraft.client.Minecraft;

public class FullbrightModule extends ClientModule {
    private float previousGamma;

    public FullbrightModule() {
        super("fullbright", "Fullbright", "Aumenta a luminosidade do jogo.");
    }

    @Override
    protected void onEnable() {
        Minecraft mc = Minecraft.func_71410_x();
        if (mc.field_71474_y != null) {
            previousGamma = mc.field_71474_y.field_74333_Y;
            mc.field_71474_y.field_74333_Y = 1000.0F;
        }
    }

    @Override
    protected void onDisable() {
        Minecraft mc = Minecraft.func_71410_x();
        if (mc.field_71474_y != null) {
            mc.field_71474_y.field_74333_Y = previousGamma;
        }
    }
}
