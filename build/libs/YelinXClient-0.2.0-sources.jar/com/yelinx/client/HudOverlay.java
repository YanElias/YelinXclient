package com.yelinx.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class HudOverlay {
    private final Minecraft mc = Minecraft.func_71410_x();

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Text event) {
        if (mc.field_71439_g == null || mc.field_71474_y.field_74330_P) return;

        int y = 6;
        if (ModuleManager.isEnabled("fps")) {
            String label = "YelinX  |  " + Minecraft.func_175610_ah() + " FPS";
            mc.field_71466_p.func_175063_a(label, 6, y, 0xFFFFD600);
            y += 12;
        }

        if (ModuleManager.isEnabled("coordinates")) {
            String coords = String.format("XYZ: %d, %d, %d",
                    (int) Math.floor(mc.field_71439_g.field_70165_t),
                    (int) Math.floor(mc.field_71439_g.field_70163_u),
                    (int) Math.floor(mc.field_71439_g.field_70161_v));
            mc.field_71466_p.func_175063_a(coords, 6, y, 0xFFF5F5F5);
        }

        if (ModuleManager.isEnabled("keystrokes")) {
            drawKeystrokes(new ScaledResolution(mc));
        }
    }

    private void drawKeystrokes(ScaledResolution resolution) {
        int box = 20;
        int gap = 2;
        int x = resolution.func_78326_a() - 68;
        int y = 8;
        drawKey("W", Keyboard.isKeyDown(Keyboard.KEY_W), x + box + gap, y, box);
        drawKey("A", Keyboard.isKeyDown(Keyboard.KEY_A), x, y + box + gap, box);
        drawKey("S", Keyboard.isKeyDown(Keyboard.KEY_S), x + box + gap, y + box + gap, box);
        drawKey("D", Keyboard.isKeyDown(Keyboard.KEY_D), x + (box + gap) * 2, y + box + gap, box);
        drawKey("LMB", Mouse.isButtonDown(0), x, y + (box + gap) * 2, 31);
        drawKey("RMB", Mouse.isButtonDown(1), x + 33, y + (box + gap) * 2, 31);
        drawKey("SP", Keyboard.isKeyDown(Keyboard.KEY_SPACE), x, y + (box + gap) * 3, 64);
    }

    private void drawKey(String label, boolean pressed, int x, int y, int width) {
        int background = pressed ? 0xFFFFD600 : 0xCC202020;
        int text = pressed ? 0xFF202020 : 0xFFF5F5F5;
        Gui.func_73734_a(x, y, x + width, y + 20, background);
        mc.field_71466_p.func_78276_b(label,
                x + (width - mc.field_71466_p.func_78256_a(label)) / 2,
                y + 6, text);
    }
}
