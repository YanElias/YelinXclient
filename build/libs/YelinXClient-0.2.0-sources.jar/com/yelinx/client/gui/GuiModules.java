package com.yelinx.client.gui;

import com.yelinx.client.ClientModule;
import com.yelinx.client.ModuleManager;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class GuiModules extends GuiScreen {
    private final GuiScreen parent;
    private int panelLeft;
    private int panelTop;
    private int panelWidth;

    public GuiModules(GuiScreen parent) {
        this.parent = parent;
    }

    @Override
    public void func_73866_w_() {
        field_146292_n.clear();
        panelWidth = Math.min(540, field_146294_l - 24);
        panelLeft = (field_146294_l - panelWidth) / 2;
        panelTop = Math.max(8, (field_146295_m - 320) / 2);

        int gap = 10;
        int cardWidth = (panelWidth - 42) / 2;
        int leftX = panelLeft + 14;
        int rightX = leftX + cardWidth + gap;
        int startY = panelTop + 66;
        int cardHeight = 70;
        int rowGap = 9;

        int i = 0;
        for (ClientModule module : ModuleManager.getModules()) {
            int col = i % 2;
            int row = i / 2;
            int x = col == 0 ? leftX : rightX;
            int y = startY + row * (cardHeight + rowGap);
            field_146292_n.add(new YelinXModuleButton(100 + i, x, y, cardWidth, cardHeight, module));
            i++;
        }
        field_146292_n.add(new YelinXButton(1, panelLeft + 14, panelTop + 280, panelWidth - 28, 26, "BACK"));
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException {
        if (button.field_146127_k >= 100 && button.field_146127_k < 100 + ModuleManager.getModules().size()) {
            int index = button.field_146127_k - 100;
            ModuleManager.toggle(ModuleManager.getModules().get(index).getId());
            func_73866_w_();
        } else if (button.field_146127_k == 1) {
            field_146297_k.func_147108_a(parent);
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        func_146276_q_();
        func_73734_a(0, 0, field_146294_l, field_146295_m, 0x66000000);
        func_73734_a(panelLeft, panelTop, panelLeft + panelWidth, panelTop + 320, 0xF51B1B1B);
        func_73734_a(panelLeft, panelTop, panelLeft + panelWidth, panelTop + 3, 0xFFFFD600);
        func_73731_b(field_146289_q, "MODULE LIBRARY", panelLeft + 16, panelTop + 14, 0xFFFFD600);
        func_73731_b(field_146289_q, "Small tools. Clear controls.", panelLeft + 16, panelTop + 31, 0xFFBDBDBD);
        String count = ModuleManager.getModules().size() + " MODULES";
        func_73731_b(field_146289_q, count, panelLeft + panelWidth - field_146289_q.func_78256_a(count) - 16,
                panelTop + 20, 0xFFF5F5F5);
        func_73734_a(panelLeft + 14, panelTop + 51, panelLeft + panelWidth - 14, panelTop + 52, 0xFF393939);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) field_146297_k.func_147108_a(parent);
        else super.func_73869_a(typedChar, keyCode);
    }

    @Override
    public boolean func_73868_f() { return false; }
}
