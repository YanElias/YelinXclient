package com.yelinx.client.gui;

import com.yelinx.client.ClientModule;
import com.yelinx.client.ModuleManager;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class GuiModules extends GuiScreen {
    private final GuiScreen parent;

    public GuiModules(GuiScreen parent) {
        this.parent = parent;
    }

    @Override
    public void func_73866_w_() {
        field_146292_n.clear();
        int panelWidth = Math.min(380, field_146294_l - 24);
        int left = (field_146294_l - panelWidth) / 2;
        int panelHeight = 100 + ModuleManager.getModules().size() * 40;
        int top = Math.max(12, (field_146295_m - panelHeight) / 2);
        int buttonWidth = panelWidth - 32;
        int y = top + 48;
        int id = 100;
        for (ClientModule module : ModuleManager.getModules()) {
            field_146292_n.add(new YelinXButton(id++, left + 16, y, buttonWidth, 22,
                    module.getName() + "  [" + (module.isEnabled() ? "ON" : "OFF") + "]"));
            y += 40;
        }
        field_146292_n.add(new YelinXButton(1, left + 16, Math.min(field_146295_m - 32, y + 2), buttonWidth, 22, "BACK"));
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException {
        if (button.field_146127_k >= 100 && button.field_146127_k < 100 + ModuleManager.getModules().size()) {
            int index = button.field_146127_k - 100;
            ModuleManager.toggle(ModuleManager.getModules().get(index).getId());
            func_73866_w_();
        } else if (button.field_146127_k == 1) {
            field_146297_k.func_147108_a(parent);
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        func_146276_q_();
        int panelWidth = Math.min(380, field_146294_l - 24);
        int left = (field_146294_l - panelWidth) / 2;
        int panelHeight = 100 + ModuleManager.getModules().size() * 40;
        int top = Math.max(12, (field_146295_m - panelHeight) / 2);
        func_73734_a(left, top, left + panelWidth, top + panelHeight, 0xF0202020);
        func_73734_a(left, top, left + panelWidth, top + 3, 0xFFFFD600);
        func_73732_a(field_146289_q, "YelinX MODULES", field_146294_l / 2, top + 13, 0xFFFFD600);
        func_73732_a(field_146289_q, "Click a module to enable or disable it", field_146294_l / 2, top + 29, 0xFFF5F5F5);
        int i = 0;
        for (ClientModule module : ModuleManager.getModules()) {
            func_73732_a(field_146289_q, module.getDescription(), field_146294_l / 2, top + 73 + i * 40, 0xFFBDBDBD);
            i++;
        }
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) field_146297_k.func_147108_a(parent);
        else super.func_73869_a(typedChar, keyCode);
    }

    @Override
    public boolean func_73868_f() { return false; }
}
