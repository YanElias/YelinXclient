package com.yelinx.client.gui;

import com.yelinx.client.ClientModule;
import com.yelinx.client.ModuleManager;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class GuiModules extends GuiScreen {
    private final GuiScreen parent;
    private int panelLeft;
    private int panelTop;
    private int panelWidth;

    public GuiModules(GuiScreen parent) {
        this.parent = parent;
    }

    @Override
    public void func_73866_w_() {
        field_146292_n.clear();
        panelWidth = Math.min(540, field_146294_l - 24);
        panelLeft = (field_146294_l - panelWidth) / 2;
        panelTop = Math.max(8, (field_146295_m - 320) / 2);

        int gap = 10;
        int cardWidth = (panelWidth - 42) / 2;
        int leftX = panelLeft + 14;
        int rightX = leftX + cardWidth + gap;
        int startY = panelTop + 69;
        int cardHeight = 70;
        int rowGap = 9;

        int i = 0;
        for (ClientModule module : ModuleManager.getModules()) {
            int col = i % 2;
            int row = i / 2;
            int x = col == 0 ? leftX : rightX;
            int y = startY + row * (cardHeight + rowGap);
            field_146292_n.add(new YelinXModuleButton(100 + i, x, y, cardWidth, cardHeight, module));
            i++;
        }
        field_146292_n.add(new YelinXButton(1, panelLeft + 14, panelTop + 280, panelWidth - 28, 26, "BACK TO MENU"));
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException {
        if (button.field_146127_k >= 100 && button.field_146127_k < 100 + ModuleManager.getModules().size()) {
            int index = button.field_146127_k - 100;
            ModuleManager.toggle(ModuleManager.getModules().get(index).getId());
            func_73866_w_();
        } else if (button.field_146127_k == 1) {
            field_146297_k.func_147108_a(parent);
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        func_146276_q_();
        func_73734_a(0, 0, field_146294_l, field_146295_m, 0x70000000);
        func_73734_a(panelLeft, panelTop, panelLeft + panelWidth, panelTop + 320, 0xF5161719);
        func_73734_a(panelLeft, panelTop, panelLeft + panelWidth, panelTop + 3, 0xFFFFD21C);
        func_73734_a(panelLeft, panelTop + 3, panelLeft + 4, panelTop + 320, 0xFFFFD21C);

        func_73731_b(field_146289_q, "MODULES", panelLeft + 16, panelTop + 15, 0xFFFFD21C);
        func_73731_b(field_146289_q, "Turn your tools on or off.", panelLeft + 16, panelTop + 32, 0xFFB8BABE);
        String count = ModuleManager.getModules().size() + " AVAILABLE";
        func_73731_b(field_146289_q, count,
                panelLeft + panelWidth - field_146289_q.func_78256_a(count) - 16,
                panelTop + 21, 0xFFF4F4F4);
        func_73734_a(panelLeft + 14, panelTop + 54, panelLeft + panelWidth - 14, panelTop + 55, 0xFF393A3D);
        func_73731_b(field_146289_q, "CLICK A CARD TO TOGGLE A MODULE", panelLeft + 16, panelTop + 263, 0xFF929499);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) field_146297_k.func_147108_a(parent);
        else super.func_73869_a(typedChar, keyCode);
    }

    @Override
    public boolean func_73868_f() { return false; }
}
