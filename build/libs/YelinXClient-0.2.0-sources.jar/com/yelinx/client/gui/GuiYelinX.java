package com.yelinx.client.gui;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class GuiYelinX extends GuiScreen {
    @Override
    public void func_73866_w_() {
        field_146292_n.clear();
        int buttonWidth = Math.min(280, field_146294_l - 36);
        int x = (field_146294_l - buttonWidth) / 2;
        int y = field_146295_m / 2 - 15;
        field_146292_n.add(new YelinXButton(0, x, y, buttonWidth, 23, "MODULES"));
        field_146292_n.add(new YelinXButton(1, x, y + 29, buttonWidth, 23, "OPTIONS"));
        field_146292_n.add(new YelinXButton(2, x, y + 58, buttonWidth, 23, "CLOSE"));
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException {
        if (button.field_146127_k == 0) field_146297_k.func_147108_a(new GuiModules(this));
        else if (button.field_146127_k == 1) field_146297_k.func_147108_a(new GuiOptions(this, field_146297_k.field_71474_y));
        else if (button.field_146127_k == 2) field_146297_k.func_147108_a(null);
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        func_146276_q_();
        int panelWidth = Math.min(330, field_146294_l - 24);
        int left = (field_146294_l - panelWidth) / 2;
        int top = field_146295_m / 2 - 92;
        func_73734_a(left, top, left + panelWidth, top + 60, 0xF0202020);
        func_73734_a(left, top, left + panelWidth, top + 3, 0xFFFFD600);
        func_73732_a(field_146289_q, "YelinX Client", field_146294_l / 2, top + 15, 0xFFFFD600);
        func_73732_a(field_146289_q, "RIGHT SHIFT  /  CLIENT MENU", field_146294_l / 2, top + 34, 0xFFF5F5F5);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) field_146297_k.func_147108_a(null);
        else super.func_73869_a(typedChar, keyCode);
    }

    @Override
    public boolean func_73868_f() { return false; }
}
