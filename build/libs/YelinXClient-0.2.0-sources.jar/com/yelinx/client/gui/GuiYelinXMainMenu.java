package com.yelinx.client.gui;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiLanguage;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class GuiYelinXMainMenu extends GuiScreen {
    @Override
    public void func_73866_w_() {
        field_146292_n.clear();
        int buttonWidth = Math.min(260, field_146294_l - 40);
        int x = (field_146294_l - buttonWidth) / 2;
        int startY = field_146295_m / 2 - 8;
        int gap = 25;
        field_146292_n.add(new YelinXButton(0, x, startY, buttonWidth, 21, "SINGLEPLAYER"));
        field_146292_n.add(new YelinXButton(1, x, startY + gap, buttonWidth, 21, "MULTIPLAYER"));
        field_146292_n.add(new YelinXButton(2, x, startY + gap * 2, buttonWidth, 21, "YELINX MODULES"));
        field_146292_n.add(new YelinXButton(3, x, startY + gap * 3, buttonWidth, 21, "OPTIONS"));
        field_146292_n.add(new YelinXButton(4, x, startY + gap * 4, buttonWidth, 21, "LANGUAGE"));
        field_146292_n.add(new YelinXButton(5, x, startY + gap * 5, buttonWidth, 21, "QUIT"));
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException {
        switch (button.field_146127_k) {
            case 0: field_146297_k.func_147108_a(new GuiSelectWorld(this)); break;
            case 1: field_146297_k.func_147108_a(new GuiMultiplayer(this)); break;
            case 2: field_146297_k.func_147108_a(new GuiModules(this)); break;
            case 3: field_146297_k.func_147108_a(new GuiOptions(this, field_146297_k.field_71474_y)); break;
            case 4: field_146297_k.func_147108_a(new GuiLanguage(this, field_146297_k.field_71474_y, field_146297_k.func_135016_M())); break;
            case 5: field_146297_k.func_71400_g(); break;
            default: break;
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        func_146276_q_();
        func_73734_a(0, 0, field_146294_l, field_146295_m, 0x55000000);
        int panelWidth = Math.min(340, field_146294_l - 24);
        int left = (field_146294_l - panelWidth) / 2;
        int top = Math.max(10, field_146295_m / 2 - 133);
        func_73734_a(left, top, left + panelWidth, top + 75, 0xD8202020);
        func_73734_a(left, top, left + panelWidth, top + 3, 0xFFFFD600);
        func_73732_a(field_146289_q, "YelinX", field_146294_l / 2, top + 13, 0xFFFFD600);
        func_73732_a(field_146289_q, "CLIENT", field_146294_l / 2, top + 29, 0xFFF5F5F5);
        func_73732_a(field_146289_q, "YOUR GAME. YOUR STYLE.", field_146294_l / 2, top + 50, 0xFFBDBDBD);
        func_73731_b(field_146289_q, "Minecraft 1.8.9", 8, field_146295_m - 18, 0xFFBDBDBD);
        String version = "YelinX 0.2.0";
        func_73731_b(field_146289_q, version, field_146294_l - field_146289_q.func_78256_a(version) - 8, field_146295_m - 18, 0xFFFFD600);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (keyCode != Keyboard.KEY_ESCAPE) super.func_73869_a(typedChar, keyCode);
    }

    @Override
    public boolean func_73868_f() { return false; }
}
