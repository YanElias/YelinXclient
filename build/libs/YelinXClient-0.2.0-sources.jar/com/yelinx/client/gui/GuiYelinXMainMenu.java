package com.yelinx.client.gui;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiLanguage;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class GuiYelinXMainMenu extends GuiScreen {
    private int panelLeft;
    private int panelTop;
    private int panelWidth;
    private int panelHeight;

    @Override
    public void func_73866_w_() {
        field_146292_n.clear();
        panelWidth = Math.min(580, field_146294_l - 24);
        panelHeight = Math.min(310, field_146295_m - 24);
        panelLeft = (field_146294_l - panelWidth) / 2;
        panelTop = (field_146295_m - panelHeight) / 2;

        int menuWidth = Math.min(154, panelWidth / 3);
        int leftX = panelLeft + 16;
        int startY = panelTop + 91;
        int rowGap = 29;
        int buttonHeight = 25;

        field_146292_n.add(new YelinXButton(0, leftX, startY, menuWidth, buttonHeight, "SINGLEPLAYER"));
        field_146292_n.add(new YelinXButton(1, leftX, startY + rowGap, menuWidth, buttonHeight, "MULTIPLAYER"));
        field_146292_n.add(new YelinXButton(2, leftX, startY + rowGap * 2, menuWidth, buttonHeight, "MODULES"));
        field_146292_n.add(new YelinXButton(3, leftX, startY + rowGap * 3, menuWidth, buttonHeight, "SETTINGS"));
        field_146292_n.add(new YelinXButton(4, leftX, startY + rowGap * 4, menuWidth, buttonHeight, "LANGUAGE"));
        field_146292_n.add(new YelinXButton(5, leftX, startY + rowGap * 5, menuWidth, buttonHeight, "QUIT GAME"));
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException {
        switch (button.field_146127_k) {
            case 0: field_146297_k.func_147108_a(new GuiSelectWorld(this)); break;
            case 1: field_146297_k.func_147108_a(new GuiMultiplayer(this)); break;
            case 2: field_146297_k.func_147108_a(new GuiModules(this)); break;
            case 3: field_146297_k.func_147108_a(new GuiOptions(this, field_146297_k.field_71474_y)); break;
            case 4: field_146297_k.func_147108_a(new GuiLanguage(this, field_146297_k.field_71474_y, field_146297_k.func_135016_M())); break;
            case 5: field_146297_k.func_71400_g(); break;
            default: break;
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        func_146276_q_();
        func_73734_a(0, 0, field_146294_l, field_146295_m, 0x70000000);

        func_73734_a(panelLeft, panelTop, panelLeft + panelWidth, panelTop + panelHeight, 0xF5161719);
        func_73734_a(panelLeft, panelTop, panelLeft + panelWidth, panelTop + 3, 0xFFFFD21C);
        func_73734_a(panelLeft, panelTop + 3, panelLeft + 4, panelTop + panelHeight, 0xFFFFD21C);

        int dividerX = panelLeft + Math.min(186, panelWidth / 3 + 22);
        func_73734_a(dividerX, panelTop + 16, dividerX + 1, panelTop + panelHeight - 16, 0xFF393A3D);

        func_73731_b(field_146289_q, "YelinX", panelLeft + 17, panelTop + 17, 0xFFFFD21C);
        func_73731_b(field_146289_q, "CLIENT", panelLeft + 17, panelTop + 31, 0xFFF4F4F4);
        func_73731_b(field_146289_q, "MINECRAFT 1.8.9", panelLeft + 17, panelTop + 49, 0xFF929499);
        func_73734_a(panelLeft + 16, panelTop + 72, dividerX - 12, panelTop + 73, 0xFF393A3D);
        func_73731_b(field_146289_q, "PLAY", panelLeft + 17, panelTop + 79, 0xFFB8BABE);

        int contentX = dividerX + 18;
        int contentWidth = panelLeft + panelWidth - contentX - 16;
        int contentTop = panelTop + 22;
        func_73731_b(field_146289_q, "YOUR GAME. YOUR WAY.", contentX, contentTop, 0xFFF4F4F4);
        func_73731_b(field_146289_q, "A cleaner Minecraft experience.", contentX, contentTop + 15, 0xFFB8BABE);

        int cardTop = contentTop + 43;
        func_73734_a(contentX, cardTop, contentX + contentWidth, cardTop + 61, 0xFF222326);
        func_73734_a(contentX, cardTop, contentX + 3, cardTop + 61, 0xFFFFD21C);
        func_73731_b(field_146289_q, "BUILT FOR YOUR NEXT WORLD", contentX + 12, cardTop + 10, 0xFFFFD21C);
        func_73731_b(field_146289_q, "Lightweight tools, right when you", contentX + 12, cardTop + 27, 0xFFE1E1E1);
        func_73731_b(field_146289_q, "need them.", contentX + 12, cardTop + 39, 0xFFE1E1E1);

        int featureTop = cardTop + 76;
        func_73731_b(field_146289_q, "CLIENT FEATURES", contentX, featureTop, 0xFFB8BABE);
        drawFeature(contentX, featureTop + 17, "01", "HUD", "FPS and coordinates");
        drawFeature(contentX, featureTop + 39, "02", "MODULES", "Quick toggles in-game");

        String version = "YELINX 0.2.0";
        func_73731_b(field_146289_q, version,
                panelLeft + panelWidth - field_146289_q.func_78256_a(version) - 16,
                panelTop + panelHeight - 17, 0xFFFFD21C);

        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    private void drawFeature(int x, int y, String number, String title, String description) {
        func_73731_b(field_146289_q, number, x, y, 0xFFFFD21C);
        func_73731_b(field_146289_q, title, x + 22, y, 0xFFF4F4F4);
        func_73731_b(field_146289_q, description, x + 22, y + 10, 0xFF929499);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (keyCode != Keyboard.KEY_ESCAPE) super.func_73869_a(typedChar, keyCode);
    }

    @Override
    public boolean func_73868_f() { return false; }
}
