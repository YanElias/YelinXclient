package com.yelinx.client.gui;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiLanguage;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class GuiYelinXMainMenu extends GuiScreen {
    private int panelLeft;
    private int panelTop;
    private int panelWidth;

    @Override
    public void func_73866_w_() {
        field_146292_n.clear();
        panelWidth = Math.min(500, field_146294_l - 24);
        panelLeft = (field_146294_l - panelWidth) / 2;
        panelTop = Math.max(12, (field_146295_m - 240) / 2);

        int gap = 8;
        int buttonWidth = (panelWidth - 44) / 2;
        int leftX = panelLeft + 14;
        int rightX = leftX + buttonWidth + gap;
        int startY = panelTop + 94;
        int rowGap = 36;

        field_146292_n.add(new YelinXButton(0, leftX, startY, buttonWidth, 28, "SINGLEPLAYER"));
        field_146292_n.add(new YelinXButton(1, rightX, startY, buttonWidth, 28, "MULTIPLAYER"));
        field_146292_n.add(new YelinXButton(2, leftX, startY + rowGap, buttonWidth, 28, "YELINX MODULES"));
        field_146292_n.add(new YelinXButton(3, rightX, startY + rowGap, buttonWidth, 28, "OPTIONS"));
        field_146292_n.add(new YelinXButton(4, leftX, startY + rowGap * 2, buttonWidth, 28, "LANGUAGE"));
        field_146292_n.add(new YelinXButton(5, rightX, startY + rowGap * 2, buttonWidth, 28, "QUIT"));
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException {
        switch (button.field_146127_k) {
            case 0: field_146297_k.func_147108_a(new GuiSelectWorld(this)); break;
            case 1: field_146297_k.func_147108_a(new GuiMultiplayer(this)); break;
            case 2: field_146297_k.func_147108_a(new GuiModules(this)); break;
            case 3: field_146297_k.func_147108_a(new GuiOptions(this, field_146297_k.field_71474_y)); break;
            case 4: field_146297_k.func_147108_a(new GuiLanguage(this, field_146297_k.field_71474_y, field_146297_k.func_135016_M())); break;
            case 5: field_146297_k.func_71400_g(); break;
            default: break;
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        func_146276_q_();
        func_73734_a(0, 0, field_146294_l, field_146295_m, 0x66000000);

        func_73734_a(panelLeft, panelTop, panelLeft + panelWidth, panelTop + 240, 0xF51B1B1B);
        func_73734_a(panelLeft, panelTop, panelLeft + panelWidth, panelTop + 3, 0xFFFFD600);
        func_73734_a(panelLeft + 14, panelTop + 15, panelLeft + 17, panelTop + 65, 0xFFFFD600);

        func_73731_b(field_146289_q, "YelinX", panelLeft + 27, panelTop + 17, 0xFFFFD600);
        func_73731_b(field_146289_q, "CLIENT", panelLeft + 27, panelTop + 31, 0xFFF5F5F5);
        func_73731_b(field_146289_q, "A cleaner way to play.", panelLeft + 27, panelTop + 49, 0xFFBDBDBD);
        func_73734_a(panelLeft + 14, panelTop + 77, panelLeft + panelWidth - 14, panelTop + 78, 0xFF393939);
        func_73731_b(field_146289_q, "QUICK ACCESS", panelLeft + 14, panelTop + 84, 0xFFBDBDBD);

        String gameVersion = "MINECRAFT 1.8.9";
        String clientVersion = "YELINX 0.2.0";
        func_73731_b(field_146289_q, gameVersion, 8, field_146295_m - 16, 0xFFBDBDBD);
        func_73731_b(field_146289_q, clientVersion, field_146294_l - field_146289_q.func_78256_a(clientVersion) - 8,
                field_146295_m - 16, 0xFFFFD600);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (keyCode != Keyboard.KEY_ESCAPE) super.func_73869_a(typedChar, keyCode);
    }

    @Override
    public boolean func_73868_f() { return false; }
}
