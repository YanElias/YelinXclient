package com.yelinx.client.gui;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class GuiYelinXPauseMenu extends GuiScreen {
    private int panelLeft;
    private int panelTop;
    private int panelWidth;

    @Override
    public void func_73866_w_() {
        field_146292_n.clear();
        panelWidth = Math.min(420, field_146294_l - 24);
        panelLeft = (field_146294_l - panelWidth) / 2;
        panelTop = Math.max(12, (field_146295_m - 224) / 2);

        int gap = 8;
        int buttonWidth = (panelWidth - 44) / 2;
        int leftX = panelLeft + 14;
        int rightX = leftX + buttonWidth + gap;
        int startY = panelTop + 91;
        field_146292_n.add(new YelinXButton(0, leftX, startY, buttonWidth, 30, "BACK TO GAME"));
        field_146292_n.add(new YelinXButton(1, rightX, startY, buttonWidth, 30, "MODULES"));
        field_146292_n.add(new YelinXButton(2, leftX, startY + 40, buttonWidth, 30, "OPTIONS"));
        field_146292_n.add(new YelinXButton(3, rightX, startY + 40, buttonWidth, 30, "SAVE & QUIT"));
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException {
        switch (button.field_146127_k) {
            case 0:
                field_146297_k.func_147108_a(null);
                field_146297_k.func_71381_h();
                break;
            case 1:
                field_146297_k.func_147108_a(new GuiModules(this));
                break;
            case 2:
                field_146297_k.func_147108_a(new GuiOptions(this, field_146297_k.field_71474_y));
                break;
            case 3:
                if (field_146297_k.field_71441_e != null) {
                    field_146297_k.field_71441_e.func_72882_A();
                    field_146297_k.func_71403_a(null);
                }
                field_146297_k.func_147108_a(new GuiYelinXMainMenu());
                break;
            default: break;
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        func_146276_q_();
        func_73734_a(0, 0, field_146294_l, field_146295_m, 0x77000000);
        func_73734_a(panelLeft, panelTop, panelLeft + panelWidth, panelTop + 184, 0xF51B1B1B);
        func_73734_a(panelLeft, panelTop, panelLeft + panelWidth, panelTop + 3, 0xFFFFD600);
        func_73731_b(field_146289_q, "PAUSED", panelLeft + 16, panelTop + 17, 0xFFFFD600);
        func_73731_b(field_146289_q, "YelinX Client", panelLeft + 16, panelTop + 33, 0xFFF5F5F5);
        func_73731_b(field_146289_q, "Your world is waiting.", panelLeft + 16, panelTop + 52, 0xFFBDBDBD);
        func_73734_a(panelLeft + 14, panelTop + 72, panelLeft + panelWidth - 14, panelTop + 73, 0xFF393939);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) {
            field_146297_k.func_147108_a(null);
            field_146297_k.func_71381_h();
        } else super.func_73869_a(typedChar, keyCode);
    }

    @Override
    public boolean func_73868_f() { return true; }
}
