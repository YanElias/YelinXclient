package com.yelinx.client.gui;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class GuiYelinXPauseMenu extends GuiScreen {
    private int panelLeft;
    private int panelTop;
    private int panelWidth;
    private int panelHeight;

    @Override
    public void func_73866_w_() {
        field_146292_n.clear();
        panelWidth = Math.min(440, field_146294_l - 24);
        panelHeight = Math.min(250, field_146295_m - 24);
        panelLeft = (field_146294_l - panelWidth) / 2;
        panelTop = (field_146295_m - panelHeight) / 2;

        int gap = 8;
        int buttonWidth = (panelWidth - 44) / 2;
        int leftX = panelLeft + 14;
        int rightX = leftX + buttonWidth + gap;
        int startY = panelTop + 105;
        field_146292_n.add(new YelinXButton(0, leftX, startY, buttonWidth, 28, "BACK TO GAME"));
        field_146292_n.add(new YelinXButton(1, rightX, startY, buttonWidth, 28, "MODULES"));
        field_146292_n.add(new YelinXButton(2, leftX, startY + 36, buttonWidth, 28, "SETTINGS"));
        field_146292_n.add(new YelinXButton(3, rightX, startY + 36, buttonWidth, 28, "SAVE & QUIT"));
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException {
        switch (button.field_146127_k) {
            case 0:
                field_146297_k.func_147108_a(null);
                field_146297_k.func_71381_h();
                break;
            case 1:
                field_146297_k.func_147108_a(new GuiModules(this));
                break;
            case 2:
                field_146297_k.func_147108_a(new GuiOptions(this, field_146297_k.field_71474_y));
                break;
            case 3:
                if (field_146297_k.field_71441_e != null) {
                    field_146297_k.field_71441_e.func_72882_A();
                    field_146297_k.func_71403_a(null);
                }
                field_146297_k.func_147108_a(new GuiYelinXMainMenu());
                break;
            default: break;
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        func_146276_q_();
        func_73734_a(0, 0, field_146294_l, field_146295_m, 0x78000000);
        func_73734_a(panelLeft, panelTop, panelLeft + panelWidth, panelTop + panelHeight, 0xF5161719);
        func_73734_a(panelLeft, panelTop, panelLeft + panelWidth, panelTop + 3, 0xFFFFD21C);
        func_73734_a(panelLeft, panelTop + 3, panelLeft + 4, panelTop + panelHeight, 0xFFFFD21C);

        func_73731_b(field_146289_q, "GAME PAUSED", panelLeft + 16, panelTop + 18, 0xFFFFD21C);
        func_73731_b(field_146289_q, "Take a break. Your world is safe.", panelLeft + 16, panelTop + 35, 0xFFF4F4F4);
        func_73731_b(field_146289_q, "YelinX Client  /  Minecraft 1.8.9", panelLeft + 16, panelTop + 53, 0xFF929499);
        func_73734_a(panelLeft + 14, panelTop + 76, panelLeft + panelWidth - 14, panelTop + 77, 0xFF393A3D);
        func_73731_b(field_146289_q, "QUICK ACTIONS", panelLeft + 16, panelTop + 87, 0xFFB8BABE);

        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) {
            field_146297_k.func_147108_a(null);
            field_146297_k.func_71381_h();
        } else super.func_73869_a(typedChar, keyCode);
    }

    @Override
    public boolean func_73868_f() { return true; }
}
