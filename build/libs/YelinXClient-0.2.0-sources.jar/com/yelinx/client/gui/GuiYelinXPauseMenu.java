package com.yelinx.client.gui;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class GuiYelinXPauseMenu extends GuiScreen {
    @Override
    public void func_73866_w_() {
        field_146292_n.clear();
        int buttonWidth = Math.min(260, field_146294_l - 40);
        int x = (field_146294_l - buttonWidth) / 2;
        int startY = field_146295_m / 2 - 32;
        int gap = 26;
        field_146292_n.add(new YelinXButton(0, x, startY, buttonWidth, 21, "BACK TO GAME"));
        field_146292_n.add(new YelinXButton(1, x, startY + gap, buttonWidth, 21, "MODULES"));
        field_146292_n.add(new YelinXButton(2, x, startY + gap * 2, buttonWidth, 21, "OPTIONS"));
        field_146292_n.add(new YelinXButton(3, x, startY + gap * 3, buttonWidth, 21, "SAVE & QUIT TO TITLE"));
    }

    @Override
    protected void func_146284_a(GuiButton button) throws IOException {
        switch (button.field_146127_k) {
            case 0:
                field_146297_k.func_147108_a(null);
                field_146297_k.func_71381_h();
                break;
            case 1:
                field_146297_k.func_147108_a(new GuiModules(this));
                break;
            case 2:
                field_146297_k.func_147108_a(new GuiOptions(this, field_146297_k.field_71474_y));
                break;
            case 3:
                if (field_146297_k.field_71441_e != null) {
                    field_146297_k.field_71441_e.func_72882_A();
                    field_146297_k.func_71403_a(null);
                }
                field_146297_k.func_147108_a(new GuiYelinXMainMenu());
                break;
            default: break;
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        func_146276_q_();
        func_73734_a(0, 0, field_146294_l, field_146295_m, 0x55000000);
        int panelWidth = Math.min(340, field_146294_l - 24);
        int left = (field_146294_l - panelWidth) / 2;
        int top = Math.max(12, field_146295_m / 2 - 93);
        func_73734_a(left, top, left + panelWidth, top + 54, 0xD8202020);
        func_73734_a(left, top, left + panelWidth, top + 3, 0xFFFFD600);
        func_73732_a(field_146289_q, "GAME PAUSED", field_146294_l / 2, top + 12, 0xFFFFD600);
        func_73732_a(field_146289_q, "YelinX Client", field_146294_l / 2, top + 30, 0xFFF5F5F5);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void func_73869_a(char typedChar, int keyCode) throws IOException {
        if (keyCode == Keyboard.KEY_ESCAPE) {
            field_146297_k.func_147108_a(null);
            field_146297_k.func_71381_h();
        } else super.func_73869_a(typedChar, keyCode);
    }

    @Override
    public boolean func_73868_f() { return true; }
}
