package com.yelinx.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;

public class YelinXButton extends GuiButton {
    private static final int YELLOW = 0xFFFFD600;
    private static final int GRAPHITE = 0xFF292929;
    private static final int HOVER = 0xFF45402B;
    private static final int MUTED = 0xFF777777;

    public YelinXButton(int id, int x, int y, int width, int height, String text) {
        super(id, x, y, width, height, text);
    }

    @Override
    public void func_146112_a(Minecraft mc, int mouseX, int mouseY) {
        if (!field_146125_m) return;
        this.field_146123_n = mouseX >= field_146128_h && mouseY >= field_146129_i
                && mouseX < field_146128_h + field_146120_f && mouseY < field_146129_i + field_146121_g;
        int background = !field_146124_l ? 0xFF202020 : (field_146123_n ? HOVER : GRAPHITE);
        func_73734_a(field_146128_h, field_146129_i, field_146128_h + field_146120_f, field_146129_i + field_146121_g, background);
        func_73734_a(field_146128_h, field_146129_i, field_146128_h + 3, field_146129_i + field_146121_g, field_146124_l ? YELLOW : MUTED);
        int color = field_146124_l ? (field_146123_n ? YELLOW : 0xFFF5F5F5) : MUTED;
        func_73732_a(mc.field_71466_p, field_146126_j, field_146128_h + field_146120_f / 2,
                field_146129_i + (field_146121_g - 8) / 2, color);
    }
}
