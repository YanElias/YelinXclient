package com.yelinx.client.gui;

import com.yelinx.client.ClientModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;

import java.util.List;

public class YelinXModuleButton extends GuiButton {
    private final ClientModule module;

    public YelinXModuleButton(int id, int x, int y, int width, int height, ClientModule module) {
        super(id, x, y, width, height, "");
        this.module = module;
    }

    @Override
    public void func_146112_a(Minecraft mc, int mouseX, int mouseY) {
        if (!field_146125_m) return;
        field_146123_n = mouseX >= field_146128_h && mouseY >= field_146129_i
                && mouseX < field_146128_h + field_146120_f && mouseY < field_146129_i + field_146121_g;

        boolean enabled = module.isEnabled();
        int background = field_146123_n ? 0xFF303030 : 0xFF252525;
        func_73734_a(field_146128_h, field_146129_i, field_146128_h + field_146120_f, field_146129_i + field_146121_g, background);
        func_73734_a(field_146128_h, field_146129_i, field_146128_h + 3, field_146129_i + field_146121_g,
                enabled ? 0xFFFFD600 : 0xFF555555);

        mc.field_71466_p.func_78276_b(module.getName(), field_146128_h + 12, field_146129_i + 10,
                enabled ? 0xFFFFD600 : 0xFFF5F5F5);

        String state = enabled ? "ON" : "OFF";
        int stateWidth = mc.field_71466_p.func_78256_a(state) + 12;
        int stateLeft = field_146128_h + field_146120_f - stateWidth - 9;
        func_73734_a(stateLeft, field_146129_i + 7, stateLeft + stateWidth, field_146129_i + 20,
                enabled ? 0xFFFFD600 : 0xFF414141);
        mc.field_71466_p.func_78276_b(state, stateLeft + 6, field_146129_i + 10,
                enabled ? 0xFF202020 : 0xFFBDBDBD);

        List<String> lines = mc.field_71466_p.func_78271_c(
                module.getDescription(), Math.max(40, field_146120_f - 24));
        int lineY = field_146129_i + 29;
        for (int i = 0; i < lines.size() && i < 2; i++) {
            mc.field_71466_p.func_78276_b(lines.get(i), field_146128_h + 12, lineY + i * 10, 0xFFBDBDBD);
        }
    }
}
